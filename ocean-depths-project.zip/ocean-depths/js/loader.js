// js/loader.js
(function () {
  const loader    = document.getElementById('loader');
  const bar       = document.getElementById('loaderBar');
  const pct       = document.getElementById('loaderPct');

  let progress = 0;
  const interval = setInterval(() => {
    // Simulate loading — fast at first, slows near end
    const increment = progress < 60 ? Math.random() * 8 + 4
                    : progress < 85 ? Math.random() * 4 + 2
                    : Math.random() * 1.5 + 0.5;
    progress = Math.min(progress + increment, 100);
    bar.style.width = progress + '%';
    pct.textContent = Math.round(progress) + '%';

    if (progress >= 100) {
      clearInterval(interval);
      setTimeout(() => {
        loader.classList.add('hidden');
        loader.setAttribute('aria-hidden', 'true');
        // Trigger hero entrance animations by letting CSS keyframes play
        document.body.classList.add('loaded');
      }, 500);
    }
  }, 80);
})();
