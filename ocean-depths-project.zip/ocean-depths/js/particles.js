// js/particles.js
(function () {
  // ── Hadal Stars ──
  const hadalStars = document.getElementById('hadalStars');
  if (hadalStars) {
    for (let i = 0; i < 120; i++) {
      const s = document.createElement('div');
      s.className = 'h-star';
      const size = Math.random() * 2.5 + 0.5;
      s.style.cssText = `
        width: ${size}px;
        height: ${size}px;
        left: ${Math.random() * 100}%;
        top: ${Math.random() * 100}%;
        animation-duration: ${Math.random() * 4 + 2}s;
        animation-delay: ${Math.random() * 6}s;
        opacity: 0.05;
      `;
      hadalStars.appendChild(s);
    }
  }

  // ── Canvas Particle System (floating bioluminescent particles) ──
  const canvas = document.getElementById('particleCanvas');
  if (!canvas) return;

  const ctx = canvas.getContext('2d');
  let W, H;
  let particles = [];
  let animId;
  let visible = false;
  const MAX_PARTICLES = 60;

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  const COLORS = [
    'rgba(0, 240, 255, ',    // cyan
    'rgba(95, 255, 170, ',   // green
    'rgba(192, 132, 252, ',  // violet
    'rgba(255, 179, 71, ',   // amber
  ];

  class Particle {
    constructor() { this.reset(true); }
    reset(initial = false) {
      this.x   = Math.random() * W;
      this.y   = initial ? Math.random() * H : H + 10;
      this.vy  = -(Math.random() * 0.4 + 0.1);
      this.vx  = (Math.random() - 0.5) * 0.3;
      this.r   = Math.random() * 2.5 + 0.5;
      this.col = COLORS[Math.floor(Math.random() * COLORS.length)];
      this.life = 0;
      this.maxLife = Math.random() * 300 + 150;
      this.phase = Math.random() * Math.PI * 2;
    }
    update() {
      this.life++;
      this.x += this.vx + Math.sin(this.life * 0.02 + this.phase) * 0.2;
      this.y += this.vy;
      if (this.life > this.maxLife || this.y < -10) this.reset();
    }
    draw() {
      const t = this.life / this.maxLife;
      const alpha = t < 0.15 ? t / 0.15
                  : t > 0.8  ? (1 - t) / 0.2
                  : 1;
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fillStyle = this.col + (alpha * 0.7) + ')';
      ctx.fill();
      // Soft glow
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r * 3, 0, Math.PI * 2);
      ctx.fillStyle = this.col + (alpha * 0.08) + ')';
      ctx.fill();
    }
  }

  for (let i = 0; i < MAX_PARTICLES; i++) particles.push(new Particle());

  function loop() {
    ctx.clearRect(0, 0, W, H);
    particles.forEach(p => { p.update(); p.draw(); });
    animId = requestAnimationFrame(loop);
  }

  // Show particles only in midnight/abyss/hadal zone
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        if (!visible) {
          visible = true;
          canvas.classList.add('visible');
          if (!animId) loop();
        }
      }
    });
  }, { threshold: 0.1 });

  const ch3 = document.getElementById('ch3');
  if (ch3) observer.observe(ch3);

  // Always run after load for performance (only if in viewport triggers it)
  window.addEventListener('scroll', () => {
    const scrollProg = window.scrollY / (document.body.scrollHeight - window.innerHeight);
    if (scrollProg > 0.35 && !visible) {
      visible = true;
      canvas.classList.add('visible');
      loop();
    }
    if (scrollProg < 0.2 && visible) {
      visible = false;
      canvas.classList.remove('visible');
      cancelAnimationFrame(animId);
      animId = null;
    }
  }, { passive: true });
})();
