// js/bubbles.js
(function () {
  const container = document.getElementById('bubblesLayer');
  if (!container) return;

  const COUNT = 22;

  for (let i = 0; i < COUNT; i++) {
    const b = document.createElement('div');
    b.className = 'bubble';
    const size = Math.random() * 16 + 5;
    const left = Math.random() * 100;
    const dur  = Math.random() * 14 + 8;
    const del  = Math.random() * 12;

    b.style.cssText = `
      width: ${size}px;
      height: ${size}px;
      left: ${left}%;
      bottom: -${size}px;
      animation-duration: ${dur}s;
      animation-delay: -${del}s;
    `;
    container.appendChild(b);
  }
})();
