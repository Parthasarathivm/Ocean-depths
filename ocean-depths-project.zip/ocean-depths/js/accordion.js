// js/accordion.js
(function () {
  const items = document.querySelectorAll('.acc-item');

  items.forEach(item => {
    const header = item.querySelector('.acc-header');
    if (!header) return;

    const toggle = () => {
      const isOpen = item.classList.contains('open');
      // Close all
      items.forEach(i => {
        i.classList.remove('open');
        i.querySelector('.acc-header')?.setAttribute('aria-expanded', 'false');
      });
      // Open clicked (if it was closed)
      if (!isOpen) {
        item.classList.add('open');
        header.setAttribute('aria-expanded', 'true');
      }
    };

    header.addEventListener('click', toggle);
    header.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        toggle();
      }
    });
  });
})();
