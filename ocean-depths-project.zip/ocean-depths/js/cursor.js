// js/cursor.js
(function () {
  const cursor = document.getElementById('cursor');
  if (!cursor) return;
  // Don't show on touch devices
  if (window.matchMedia('(hover: none)').matches) {
    cursor.style.display = 'none';
    return;
  }

  let mx = -100, my = -100;
  let cx = -100, cy = -100;
  let raf;

  document.addEventListener('mousemove', (e) => {
    mx = e.clientX;
    my = e.clientY;
  });

  // Smooth follow
  function animate() {
    cx += (mx - cx) * 0.18;
    cy += (my - cy) * 0.18;
    cursor.style.left = cx + 'px';
    cursor.style.top  = cy + 'px';
    raf = requestAnimationFrame(animate);
  }
  animate();

  // Hover state on interactive elements
  const interactives = 'a, button, .c-card, .bio-orb, .acc-header, .is-card, .fc-card, .fact-chip, .dt-point, .ch-dot, .nav-dot';
  document.querySelectorAll(interactives).forEach(el => {
    el.addEventListener('mouseenter', () => document.body.classList.add('cursor-hover'));
    el.addEventListener('mouseleave', () => document.body.classList.remove('cursor-hover'));
  });

  document.addEventListener('mouseleave', () => {
    cursor.style.opacity = '0';
  });
  document.addEventListener('mouseenter', () => {
    cursor.style.opacity = '1';
  });
})();
