// js/scroll.js
(function () {
  // ── DOM refs ──
  const dmValue   = document.getElementById('dmValue');
  const dmFill    = document.getElementById('dmFill');
  const scrollFill = document.getElementById('scrollFill');
  const chDots    = document.querySelectorAll('.ch-dot');
  const reveals   = document.querySelectorAll('.reveal');
  const pvBars    = document.querySelectorAll('.pv-bar-fill');
  const chapters  = document.querySelectorAll('.chapter');
  const MAX_DEPTH = 11034;

  // ── Background gradient stops per chapter ──
  // [r, g, b]
  const bgStops = [
    [15, 180, 204],   // ch0 hero teal
    [6,  24,  48],    // ch1 intro dark blue
    [5,  15,  30],    // ch2 twilight near-black blue
    [3,  12,  24],    // ch3 midnight very dark
    [2,   8,  16],    // ch4 abyss almost black
    [1,   4,   8],    // ch5 hadal blackest
  ];

  function lerp(a, b, t) { return a + (b - a) * t; }
  function lerpRGB(c1, c2, t) {
    return [
      Math.round(lerp(c1[0], c2[0], t)),
      Math.round(lerp(c1[1], c2[1], t)),
      Math.round(lerp(c1[2], c2[2], t)),
    ];
  }

  // ── Scroll state ──
  let activeCh = 0;

  function onScroll() {
    const scrollY = window.scrollY;
    const total   = document.body.scrollHeight - window.innerHeight;
    const prog    = total > 0 ? Math.min(scrollY / total, 1) : 0;

    // ── Scroll progress bar ──
    scrollFill.style.width = (prog * 100) + '%';

    // ── Depth meter ──
    const depth = Math.round(prog * MAX_DEPTH);
    dmValue.textContent = depth > 999
      ? Math.round(depth / 10) / 100 + 'km'
      : depth + 'm';
    dmFill.style.height = (prog * 100) + '%';

    // ── Background colour blend ──
    const pos  = prog * (bgStops.length - 1);
    const idx  = Math.min(Math.floor(pos), bgStops.length - 2);
    const t    = pos - idx;
    const [r, g, b] = lerpRGB(bgStops[idx], bgStops[idx + 1], t);
    document.body.style.backgroundColor = `rgb(${r},${g},${b})`;

    // ── Active chapter nav dot ──
    let current = 0;
    chapters.forEach((ch, i) => {
      const rect = ch.getBoundingClientRect();
      if (rect.top <= window.innerHeight * 0.55) current = i;
    });
    if (current !== activeCh) {
      chDots[activeCh]?.classList.remove('active');
      chDots[current]?.classList.add('active');
      activeCh = current;
    }

    // ── Reveal elements ──
    reveals.forEach(el => {
      if (el.classList.contains('visible')) return;
      const rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.88) {
        el.classList.add('visible');
      }
    });

    // ── Pressure bars (abyss section) ──
    pvBars.forEach(bar => {
      const rect = bar.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.9) {
        bar.classList.add('animated');
      }
    });

    // ── Parallax on hero BG layers ──
    const hbl1 = document.querySelector('.hbl-1');
    const hbl2 = document.querySelector('.hbl-2');
    if (hbl1) hbl1.style.transform = `translateY(${scrollY * 0.25}px)`;
    if (hbl2) hbl2.style.transform = `translateY(${scrollY * 0.15}px)`;
    const caustics = document.querySelector('.caustics');
    if (caustics) caustics.style.transform = `translateY(${scrollY * 0.1}px)`;
    const coralFloor = document.querySelector('.coral-floor');
    if (coralFloor) coralFloor.style.transform = `translateY(${scrollY * 0.06}px)`;
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll(); // init on load

  // ── Chapter nav dot clicks ──
  chDots.forEach((dot, i) => {
    dot.addEventListener('click', () => {
      chapters[i]?.scrollIntoView({ behavior: 'smooth' });
    });
  });

  // ── Keyboard nav (arrow keys) ──
  document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || e.key === 'PageDown') {
      e.preventDefault();
      const next = Math.min(activeCh + 1, chapters.length - 1);
      chapters[next]?.scrollIntoView({ behavior: 'smooth' });
    }
    if (e.key === 'ArrowUp' || e.key === 'PageUp') {
      e.preventDefault();
      const prev = Math.max(activeCh - 1, 0);
      chapters[prev]?.scrollIntoView({ behavior: 'smooth' });
    }
  });
})();
